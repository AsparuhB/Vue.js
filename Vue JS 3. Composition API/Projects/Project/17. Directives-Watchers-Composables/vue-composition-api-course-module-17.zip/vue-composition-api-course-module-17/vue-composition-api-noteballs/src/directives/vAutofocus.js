export const vAutofocus = {
  mounted: (el) => {
    el.focus()
  }
}
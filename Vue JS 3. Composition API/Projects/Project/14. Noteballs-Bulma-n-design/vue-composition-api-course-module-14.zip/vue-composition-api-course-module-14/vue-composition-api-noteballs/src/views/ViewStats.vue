<template>
  <div class="stats">
    <h1>Stats</h1>
  </div>
</template>